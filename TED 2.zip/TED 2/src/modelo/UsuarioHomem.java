package modelo;

public class UsuarioHomem extends Usuario {
	
	public UsuarioHomem (String nome) {
		this.nome = nome;
		System.out.println("Seja bem-vindo, Senhor " + this.nome);
	}
	
	

}
